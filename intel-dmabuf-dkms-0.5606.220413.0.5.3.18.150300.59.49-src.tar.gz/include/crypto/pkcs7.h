/* Automatically created during backport process */
#ifndef CPTCFG_BPAUTO_PKCS7
#include_next <crypto/pkcs7.h>
#else
#include <crypto/backport-pkcs7.h>
#endif /* CPTCFG_BPAUTO_PKCS7 */
