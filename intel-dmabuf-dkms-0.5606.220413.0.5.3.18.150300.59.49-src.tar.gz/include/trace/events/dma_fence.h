/* Automatically created during backport process */
#ifndef CPTCFG_BPAUTO_DMA_FENCE_TRACE
#include_next <trace/events/dma_fence.h>
#else
#include <trace/events/backport-dma_fence.h>
#endif /* CPTCFG_BPAUTO_DMA_FENCE_TRACE */
