#ifndef STUB_X86_ASM_TSC_H
#define STUB_X86_ASM_TSC_H

/* Should never be used by dgfx */
#define tsc_khz 2000

#endif
