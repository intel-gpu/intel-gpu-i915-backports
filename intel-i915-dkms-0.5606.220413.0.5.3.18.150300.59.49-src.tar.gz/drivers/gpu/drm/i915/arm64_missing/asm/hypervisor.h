#ifndef _ASM_X86_HYPERVISOR_H
#define _ASM_X86_HYPERVISOR_H

#define hypervisor_is_type(x)	0

#endif
