#ifndef STUB_X86_DRM_INTEL_GTT_H
#define STUB_X86_DRM_INTEL_GTT_H

#include_next <drm/intel-gtt.h>

#endif
