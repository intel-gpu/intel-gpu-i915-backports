/* SPDX-License-Identifier: MIT */
/*
 * Copyright © 2019 Intel Corporation
 */

#ifndef INTEL_LLC_TYPES_H
#define INTEL_LLC_TYPES_H

struct intel_llc {
};

#endif /* INTEL_LLC_TYPES_H */
